document.addEventListener('DOMContentLoaded', async () => {
  const openManagerBtn = document.getElementById('open-manager');
  const syncMacrosBtn = document.getElementById('sync-macros');
  const macroList = document.getElementById('macro-list');

  // Debug: verificar se os elementos existem
  console.log('Popup carregado:', {
    openManagerBtn: !!openManagerBtn,
    syncMacrosBtn: !!syncMacrosBtn,
    macroList: !!macroList
  });

  // Abrir o gerenciador de macros
  openManagerBtn.addEventListener('click', async () => {
    console.log('Botão clicado - tentando abrir gerenciador');
    
    try {
      // Verificar se chrome.runtime está disponível
      if (!chrome || !chrome.runtime) {
        throw new Error('Chrome runtime não disponível');
      }
      
      // Verificar se chrome.tabs está disponível
      if (!chrome.tabs) {
        throw new Error('Chrome tabs API não disponível');
      }
      
      const extensionId = chrome.runtime.id;
      console.log('Extension ID:', extensionId);
      
      // Tentar diferentes URLs
      const urls = [
        chrome.runtime.getURL('dist/index.html'),
        `chrome-extension://${extensionId}/dist/index.html`,
        chrome.runtime.getURL('index.html'),
        `chrome-extension://${extensionId}/index.html`
      ];
      
      console.log('URLs para tentar:', urls);
      
      let success = false;
      
      for (const url of urls) {
        try {
          console.log('Tentando abrir:', url);
          
          const tab = await chrome.tabs.create({ 
            url: url,
            active: true 
          });
          
          console.log('Aba criada com sucesso:', tab.id, 'URL:', tab.url);
          success = true;
          
          // Fechar o popup após um pequeno delay
          setTimeout(() => {
            window.close();
          }, 100);
          
          break;
        } catch (urlError) {
          console.error(`Erro com URL ${url}:`, urlError);
        }
      }
      
      if (!success) {
        throw new Error('Nenhuma URL funcionou');
      }
      
    } catch (error) {
      console.error('Erro ao abrir gerenciador:', error);
      
      // Mostrar erro para o usuário
      alert(`Erro ao abrir gerenciador: ${error.message}\n\nVerifique se a extensão foi instalada corretamente.`);
    }
  });

  // Sincronizar macros
  syncMacrosBtn.addEventListener('click', async () => {
    console.log('Sincronizando macros...');
    
    syncMacrosBtn.textContent = 'Sincronizando...';
    syncMacrosBtn.disabled = true;
    
    try {
      // Tentar carregar macros do gerenciador web (se estiver aberto)
      const tabs = await chrome.tabs.query({});
      const managerTab = tabs.find(tab => 
        tab.url && (
          tab.url.includes('dist/index.html') || 
          tab.url.includes('/index.html')
        )
      );
      
      if (managerTab) {
        console.log('Gerenciador encontrado na aba:', managerTab.id);
        try {
          await chrome.tabs.sendMessage(managerTab.id, { action: 'syncMacros' });
        } catch (error) {
          console.log('Não foi possível comunicar com o gerenciador:', error);
        }
      }
      
      // Recarregar macros do storage local
      await loadMacros();
      
      // Notificar todos os content scripts sobre a atualização
      const allTabs = await chrome.tabs.query({});
      for (const tab of allTabs) {
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'reloadMacros' });
        } catch (error) {
          // Ignorar erros de tabs que não têm content script
        }
      }
      
      syncMacrosBtn.textContent = 'Sincronizado!';
      setTimeout(() => {
        syncMacrosBtn.textContent = 'Sincronizar';
        syncMacrosBtn.disabled = false;
      }, 1500);
    } catch (error) {
      console.error('Erro ao sincronizar:', error);
      syncMacrosBtn.textContent = 'Erro';
      setTimeout(() => {
        syncMacrosBtn.textContent = 'Sincronizar';
        syncMacrosBtn.disabled = false;
      }, 2000);
    }
  });

  // Carregar e exibir macros
  async function loadMacros() {
    try {
      const result = await chrome.storage.local.get(['macros']);
      const macros = result.macros || [];
      
      console.log('Macros carregadas no popup:', macros);
      
      if (macros.length === 0) {
        macroList.innerHTML = `
          <div class="empty-state">
            <p>Nenhuma macro encontrada</p>
            <p>Clique em "Abrir Gerenciador" para criar suas primeiras macros.</p>
          </div>
        `;
      } else {
        macroList.innerHTML = macros.map(macro => `
          <div class="macro-item">
            <div class="macro-info">
              <div class="macro-name">${escapeHtml(macro.name)}</div>
              <div class="macro-shortcut">${escapeHtml(macro.shortcut)}</div>
            </div>
          </div>
        `).join('');
      }
    } catch (error) {
      console.error('Erro ao carregar macros:', error);
      macroList.innerHTML = `
        <div class="empty-state">
          <p>Erro ao carregar macros</p>
        </div>
      `;
    }
  }

  // Função para escapar HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Carregar macros ao abrir o popup
  await loadMacros();
  
  console.log('Popup inicializado completamente');
});