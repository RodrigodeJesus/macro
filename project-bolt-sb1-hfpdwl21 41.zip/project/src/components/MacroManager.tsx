import React, { useState, useEffect } from 'react';
import { supabase, Macro } from '../lib/supabase';
import { User } from '@supabase/supabase-js';
import { Plus, Edit2, Trash2, LogOut, Save, X, RefreshCw } from 'lucide-react';

interface MacroManagerProps {
  user: User;
}

export function MacroManager({ user }: MacroManagerProps) {
  const [macros, setMacros] = useState<Macro[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMacro, setEditingMacro] = useState<Macro | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    shortcut: '',
    content: ''
  });

  useEffect(() => {
    loadMacros();
    
    // Escutar mensagens da extensão
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.action === 'syncMacros') {
        syncMacrosWithExtension();
      }
    };
    
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const loadMacros = async () => {
    try {
      const { data, error } = await supabase
        .from('macros')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMacros(data || []);
      
      // Sincronizar automaticamente com a extensão
      syncMacrosWithExtension(data || []);
    } catch (error) {
      console.error('Erro ao carregar macros:', error);
    } finally {
      setLoading(false);
    }
  };

  const syncMacrosWithExtension = async (macrosToSync?: Macro[]) => {
    setSyncing(true);
    try {
      const macrosData = macrosToSync || macros;
      
      // Verificar se estamos em uma extensão
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        await chrome.runtime.sendMessage({
          action: 'syncMacros',
          macros: macrosData
        });
        console.log('Macros sincronizadas com a extensão:', macrosData);
      } else {
        console.log('Não está rodando como extensão, sincronização pulada');
      }
    } catch (error) {
      console.error('Erro ao sincronizar com extensão:', error);
    } finally {
      setSyncing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingMacro) {
        const { error } = await supabase
          .from('macros')
          .update({
            name: formData.name,
            shortcut: formData.shortcut,
            content: formData.content,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingMacro.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('macros')
          .insert({
            user_id: user.id,
            name: formData.name,
            shortcut: formData.shortcut,
            content: formData.content
          });

        if (error) throw error;
      }

      setFormData({ name: '', shortcut: '', content: '' });
      setShowForm(false);
      setEditingMacro(null);
      await loadMacros(); // Isso já vai sincronizar automaticamente
    } catch (error) {
      console.error('Erro ao salvar macro:', error);
    }
  };

  const handleEdit = (macro: Macro) => {
    setEditingMacro(macro);
    setFormData({
      name: macro.name,
      shortcut: macro.shortcut,
      content: macro.content
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta macro?')) return;

    try {
      const { error } = await supabase
        .from('macros')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await loadMacros(); // Isso já vai sincronizar automaticamente
    } catch (error) {
      console.error('Erro ao excluir macro:', error);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingMacro(null);
    setFormData({ name: '', shortcut: '', content: '' });
  };

  const handleManualSync = async () => {
    await syncMacrosWithExtension();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">MacroExpress</h1>
              <p className="text-gray-600">Gerencie suas macros de texto</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleManualSync}
                disabled={syncing}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center gap-2 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
                {syncing ? 'Sincronizando...' : 'Sincronizar'}
              </button>
              <button
                onClick={() => setShowForm(true)}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Nova Macro
              </button>
              <button
                onClick={handleLogout}
                className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Sair
              </button>
            </div>
          </div>

          {showForm && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">
                {editingMacro ? 'Editar Macro' : 'Nova Macro'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome da Macro
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Ex: Saudação"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Atalho
                  </label>
                  <input
                    type="text"
                    value={formData.shortcut}
                    onChange={(e) => setFormData({ ...formData, shortcut: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Ex: -oi"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Conteúdo
                  </label>
                  <textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    rows={4}
                    placeholder="Ex: Olá! Como posso ajudá-lo hoje?"
                    required
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Salvar
                  </button>
                  <button
                    type="button"
                    onClick={cancelForm}
                    className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="space-y-4">
            {macros.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>Nenhuma macro cadastrada ainda.</p>
                <p>Clique em "Nova Macro" para começar!</p>
              </div>
            ) : (
              macros.map((macro) => (
                <div key={macro.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{macro.name}</h3>
                      <p className="text-sm text-indigo-600 font-mono bg-indigo-50 px-2 py-1 rounded inline-block mt-1">
                        {macro.shortcut}
                      </p>
                      <p className="text-gray-700 mt-2">{macro.content}</p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => handleEdit(macro)}
                        className="text-indigo-600 hover:text-indigo-700 p-1"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(macro.id)}
                        className="text-red-600 hover:text-red-700 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}