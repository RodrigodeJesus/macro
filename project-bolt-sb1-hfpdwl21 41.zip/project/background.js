// Background script para gerenciar a extensão
chrome.runtime.onInstalled.addListener(() => {
  console.log('MacroExpress instalado');
});

// Sincronizar macros do Supabase com o storage local
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncMacros') {
    chrome.storage.local.set({ macros: request.macros }, () => {
      console.log('Macros sincronizadas:', request.macros);
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getMacros') {
    chrome.storage.local.get(['macros'], (result) => {
      console.log('Macros recuperadas:', result.macros);
      sendResponse({ macros: result.macros || [] });
    });
    return true;
  }

  if (request.action === 'loadMacrosFromSupabase') {
    // Esta ação será chamada pelo popup para carregar macros do Supabase
    sendResponse({ success: true });
    return true;
  }
});

// Listener para quando a extensão é iniciada
chrome.runtime.onStartup.addListener(() => {
  console.log('MacroExpress iniciado');
});