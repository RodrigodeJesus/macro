(function () {
  'use strict';

  let macros = [];

  async function loadMacros() {
    try {
      const result = await chrome.storage.local.get(['macros']);
      macros = result.macros || [];
      console.log("[MacroExpress] Macros carregadas:", macros.length);
    } catch (error) {
      console.error("[MacroExpress] Erro ao carregar macros:", error);
    }
  }

  function isGoogleDocs() {
    return window.location.hostname === "docs.google.com";
  }

  function handleInputEvent(e) {
    const active = document.activeElement;
    if (!active || (!['INPUT', 'TEXTAREA'].includes(active.tagName) && !active.isContentEditable)) return;

    setTimeout(async () => {
      let value = active.value !== undefined ? active.value : active.innerText;

      for (const macro of macros) {
        if (value.endsWith(macro.trigger)) {
          if (isGoogleDocs()) {
            await navigator.clipboard.writeText(macro.content);
            alert(`Texto copiado para o clipboard! Pressione Ctrl+V para colar no Google Docs.`);
            return;
          }

          const newValue = value.replace(macro.trigger, macro.content);

          if (active.value !== undefined) {
            active.value = newValue;
          } else {
            active.innerText = newValue;

            const range = document.createRange();
            const sel = window.getSelection();
            range.selectNodeContents(active);
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
          }

          break;
        }
      }
    }, 10);
  }

  function observeEditableFields() {
    document.addEventListener("keydown", handleInputEvent, true);
  }

  (async function init() {
    await loadMacros();
    observeEditableFields();
  })();
})();
