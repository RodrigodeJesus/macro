/*
  # Fix user signup database error

  1. Policies
    - Drop and recreate INSERT policies for users table
    - Allow service_role to insert users (for auth service)
    - Allow authenticated users to insert their own profile

  2. Functions
    - Update handle_new_user function with proper error handling
    - Update create_user_settings function

  3. Triggers
    - Ensure trigger exists on auth.users table
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow auth service to insert users" ON users;
DROP POLICY IF EXISTS "Users can insert own profile" ON users;

-- Allow Supabase auth service to insert new users
CREATE POLICY "Allow auth service to insert users"
  ON users
  FOR INSERT
  TO service_role
  WITH CHECK (true);

-- Allow authenticated users to insert their own user record (for the trigger)
CREATE POLICY "Users can insert own profile"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Update the handle_new_user function to properly handle user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into public.users table
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (NEW.id, NEW.email, NOW(), NOW())
  ON CONFLICT (id) DO NOTHING;
  
  -- Insert default user settings
  INSERT INTO public.user_settings (user_id, premium, ad_free, max_macros, subscription_status, created_at, updated_at)
  VALUES (NEW.id, false, false, 5, 'inactive', NOW(), NOW())
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure the trigger exists on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Update the create_user_settings function as well
CREATE OR REPLACE FUNCTION create_user_settings()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_settings (user_id, premium, ad_free, max_macros, subscription_status, created_at, updated_at)
  VALUES (NEW.id, false, false, 5, 'inactive', NOW(), NOW())
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;