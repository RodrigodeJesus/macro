/*
  # Fix user signup database functions and triggers

  1. Database Functions
    - `update_updated_at_column()` - Updates the updated_at timestamp
    - `handle_new_user()` - Creates user profile when new auth user is created
    - `create_user_settings()` - Creates default user settings

  2. Triggers
    - Trigger on auth.users to automatically create user profile and settings
    - Triggers on tables to update updated_at timestamps

  3. Security
    - Ensure proper RLS policies are in place
    - Allow service role to manage user creation process
*/

-- Function to update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to handle new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into public.users table
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (NEW.id, NEW.email, now(), now());
  
  -- Insert into user_settings table with default values
  INSERT INTO public.user_settings (
    user_id, 
    premium, 
    ad_free, 
    max_macros, 
    subscription_status,
    created_at, 
    updated_at
  )
  VALUES (
    NEW.id, 
    false, 
    false, 
    5, 
    'inactive',
    now(), 
    now()
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create user settings (alternative approach)
CREATE OR REPLACE FUNCTION create_user_settings()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_settings (
    user_id, 
    premium, 
    ad_free, 
    max_macros, 
    subscription_status,
    created_at, 
    updated_at
  )
  VALUES (
    NEW.id, 
    false, 
    false, 
    5, 
    'inactive',
    now(), 
    now()
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_user_settings_updated_at ON public.user_settings;
DROP TRIGGER IF EXISTS update_macros_updated_at ON public.macros;

-- Create trigger on auth.users for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Create triggers for updating updated_at timestamps
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_settings_updated_at
  BEFORE UPDATE ON public.user_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_macros_updated_at
  BEFORE UPDATE ON public.macros
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Ensure RLS policies allow the service role to insert users
-- This is needed for the trigger function to work properly
DO $$
BEGIN
  -- Check if policy exists before creating
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND policyname = 'Allow service role to insert users'
  ) THEN
    CREATE POLICY "Allow service role to insert users"
      ON public.users
      FOR INSERT
      TO service_role
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_settings' 
    AND policyname = 'Allow service role to insert user settings'
  ) THEN
    CREATE POLICY "Allow service role to insert user settings"
      ON public.user_settings
      FOR INSERT
      TO service_role
      WITH CHECK (true);
  END IF;
END $$;