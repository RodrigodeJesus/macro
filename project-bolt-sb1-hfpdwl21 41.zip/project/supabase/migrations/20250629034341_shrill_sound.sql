/*
  # Fix user creation database errors

  1. Database Structure
    - Clean up existing triggers and functions properly
    - Create robust user creation system
    - Add proper error handling

  2. Security
    - Enable RLS on all tables
    - Add policies for service_role and authenticated users
    - Ensure proper access control

  3. Functions
    - Create update_updated_at_column function
    - Create handle_new_user function with error handling
    - Add triggers for automatic user and settings creation
*/

-- Remove todos os triggers existentes que podem estar causando problemas
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS create_user_settings_trigger ON auth.users;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_user_settings_updated_at ON public.user_settings;
DROP TRIGGER IF EXISTS update_macros_updated_at ON public.macros;

-- Remove funções existentes com CASCADE para remover dependências
DROP FUNCTION IF EXISTS handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS create_user_settings() CASCADE;
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- Cria função simples para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Cria função para lidar com novos usuários de forma mais robusta
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  user_exists boolean;
  settings_exists boolean;
BEGIN
  -- Verifica se o usuário já existe na tabela users
  SELECT EXISTS(SELECT 1 FROM public.users WHERE id = NEW.id) INTO user_exists;
  
  -- Se não existe, cria o registro
  IF NOT user_exists THEN
    INSERT INTO public.users (id, email, created_at, updated_at)
    VALUES (NEW.id, NEW.email, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
  END IF;
  
  -- Verifica se as configurações já existem
  SELECT EXISTS(SELECT 1 FROM public.user_settings WHERE user_id = NEW.id) INTO settings_exists;
  
  -- Se não existem, cria as configurações padrão
  IF NOT settings_exists THEN
    INSERT INTO public.user_settings (
      user_id, 
      premium, 
      ad_free, 
      max_macros, 
      subscription_status,
      created_at, 
      updated_at
    )
    VALUES (
      NEW.id, 
      false, 
      false, 
      5, 
      'inactive',
      CURRENT_TIMESTAMP, 
      CURRENT_TIMESTAMP
    );
  END IF;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Em caso de erro, registra no log mas não falha
    RAISE WARNING 'Erro ao criar usuário: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recria o trigger principal
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Recria triggers para updated_at
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_settings_updated_at
  BEFORE UPDATE ON public.user_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_macros_updated_at
  BEFORE UPDATE ON public.macros
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Remove políticas existentes que podem estar conflitando
DROP POLICY IF EXISTS "Allow service role to insert users" ON public.users;
DROP POLICY IF EXISTS "Allow service role to insert user settings" ON public.user_settings;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
DROP POLICY IF EXISTS "Users can insert own settings" ON public.user_settings;

-- Cria políticas necessárias para o service_role (usado pelos triggers)
CREATE POLICY "Allow service role to insert users"
  ON public.users
  FOR INSERT
  TO service_role
  WITH CHECK (true);

CREATE POLICY "Allow service role to insert user settings"
  ON public.user_settings
  FOR INSERT
  TO service_role
  WITH CHECK (true);

-- Permite que usuários autenticados insiram seus próprios dados (backup)
CREATE POLICY "Users can insert own profile"
  ON public.users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own settings"
  ON public.user_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);